package com.fatimamustafa.smdproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class notification_screen_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_screen);
    }
}