package com.fatimamustafa.smdproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class add__record__activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_record);
    }
}