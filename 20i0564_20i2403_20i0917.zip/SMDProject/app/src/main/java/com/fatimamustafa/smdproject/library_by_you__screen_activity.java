package com.fatimamustafa.smdproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class library_by_you__screen_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.library_by_you_screen);
    }
}